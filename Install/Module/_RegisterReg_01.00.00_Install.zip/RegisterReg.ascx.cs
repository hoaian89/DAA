﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Collections;
using System.Data.SqlClient;
using DotNetNuke.Entities.Modules;

//  State
//  0 : if registered then show Register Info
//  1 : if not then show Schedule 
//  2 : if edit button pressed then edit Info
//  1,2 --> 3 : Confirm --> 4 : Successful --> 0

public partial class DesktopModules_RegisterReg_RegisterReg : PortalModuleBase
{
    #region//  Variable's infomations
    protected string ConnectionString;
    private SqlDataSource studentsource;
    private int subRegifReReg;
    protected SqlDataSource scheduleSource;
    protected GridView schedule;
    public string HeightofDIV = "490px";
    protected List<GridViewRow> listSubID;
    protected bool UpdateSate = false;
    protected List<String> Reregsubject;
    protected String userName;
    #endregion

    protected void StudentDataSource_Load(object sender, EventArgs e)
    {
        studentsource = (SqlDataSource)sender;
        if (!Page.IsPostBack)
            studentsource.SelectParameters["StuId"].DefaultValue = userName;
    }

    int getInt(object o)
    {
        if (o is int) return (int)o;
        else return 0;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["SiteSqlServer"].ToString() +
        ";MultipleActiveResultSets = True;";
        Reregsubject = new List<String>();
        userName = HttpContext.Current.User.Identity.Name;

        if (!IsPostBack)
        {
            if (Session["State"] == null) Session.Add("State", 0);
            else Session["State"] = 0;
            CheckStateInfo();

            using (SqlConnection scon = new SqlConnection(ConnectionString))
            {
                scon.Open();
                using (SqlCommand scom = new SqlCommand("Select sum(Credits) from Subject as S , Mark as M " +
                "where (S.SubID = M.SubID) and (M.StuID = @StuID)", scon))
                {
                    scom.Parameters.Add("@StuID", userName);
                    try { Dahoc.Text = (getInt(scom.ExecuteScalar())).ToString(); }
                    catch (Exception ex) { }
                    scom.CommandText = "select sum(Credits) from Subject as S , Mark as M " +
                    "where (S.SubID = M.SubID) and ( M.StuID = @StuID ) and ( Mark >= 50 )";
                    try { DaTL.Text = (getInt(scom.ExecuteScalar())).ToString(); }
                    catch (Exception ex) { }
                }
            }
            SetDisplayForm();
        }
    }

    //  Set dislay base on state info 
    void SetDisplayForm()
    {
        if (GetState() == 0)
        {
            EditButton1.Text = "Sửa đổi";
            PrintButton1.Text = "Hủy tất cả";
            GridView1.Columns[GridView1.Columns.Count - 1].Visible = false;
            DropDownList1.Visible = false;
            ShowInfo.Text = "";
            Label3.Text = "Bạn đã đăng kí học phần gồm các môn sau : ";
            PrintButton1.OnClientClick = "return confirm('Bạn có chắc muốn hủy các môn đã đăng kí không ?')";
        }
        else
        {
            PrintButton1.OnClientClick = "";
            if (GetState() == 1 || GetState() == 5)
            {
                EditButton1.Text = "Đăng kí";
                PrintButton1.Text = "Hủy";
                GridView1.Columns[GridView1.Columns.Count - 1].Visible = true;
                DropDownList1.Visible = true;
                Label3.Text = "Chọn loại môn : ";
                ShowInfo.Text = "";

            }
            else { DropDownList1.Visible = false; }
        }
    }

    //  Check state info
    int CheckStateInfo()
    {
        using (SqlConnection scon = new SqlConnection(ConnectionString))
        {
            scon.Open();
            using (SqlCommand scom = new SqlCommand("Select count(*) from RegisterInfo where (StuID = @StuID)", scon))
            {
                scom.Parameters.Add("@StuID", userName);
                try
                {
                    if (getInt(scom.ExecuteScalar()) > 0)
                    {
                        scom.CommandText = "Select Sum(ReReg) from RegisterInfo where (StuID = @StuID)";
                        subRegifReReg = getInt(scom.ExecuteScalar());
                    }
                    else
                    {
                        Session["State"] = 1;
                    }
                }
                catch (Exception ex) { }
            }
        }
        return GetState();
    }

    void Clear()
    {
        using (SqlConnection scon = new SqlConnection(ConnectionString))
        {
            scon.Open();
            using (SqlCommand scom = new SqlCommand("Delete from RegisterInfo where (StuID = @StuID )", scon))
            {
                scom.Parameters.Add("@StuID", userName);
                try
                {
                    scom.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "Hoàn tất",
                        "alert('Đã xóa tất cả các môn đăng kí !')", true);
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "Thông báo lỗi",
                        "alert('Có một số lỗi xảy ra !')", true);
                }

                //  Update CurNm
                scom.CommandText = "Update ScheduleM set CurNm = (select count(*) from RegisterInfo " +
                    "where ScheduleM.ClassID = RegisterInfo.ClassID)";
                try { scom.ExecuteNonQuery(); }
                catch (Exception ex) { }
            }
        }
    }

    protected void PrintButton_Click(object sender, EventArgs e)
    {
        if (GetState() == 0) { Clear(); Session["State"] = 1; }
        else Session["State"] = 0;
        DropDownList1.Enabled = true;
        CheckStateInfo();
        SetDisplayForm();
        SetDataSourceInfo();
    }

    protected void GridView1_Load(object sender, EventArgs e)
    {
        schedule = (GridView)sender;
    }

    protected void SqlDataSource1_Load(object sender, EventArgs e)
    {
        scheduleSource = (SqlDataSource)sender;
        if (!IsPostBack) SetDataSourceInfo();
    }

    void SetDataSourceInfo()
    {
        if (GetState() == 0)
        {
            scheduleSource.SelectCommand = "SELECT [Typ],S.SubID,[SubNm],R.ClassID,[Credits],[StuMx],[LecNm],[Day],[Period],[Room],[CurNm] FROM RegisterInfo as R,ScheduleM as S,Subject as S1" +
             " where (R.ClassID = S.ClassID) and (S1.SubID = R.SubID) and (R.StuID = '" + userName + "') ORDER BY [Room]";
        }
        else
            scheduleSource.SelectCommand = "SELECT [Typ],S.SubID,[SubNm],[ClassID],[Credits],[StuMx],[LecNm],[Day],[Period],[Room],[CurNm] FROM [ScheduleM] as S,Subject as S1 " +
            " where S.SubID = S1.SubID ORDER BY [Room] ";

        GridView1.DataBind();
    }

    bool Contains(List<GridViewRow> list, string SubID)
    {
        foreach (GridViewRow grow in list)
        {
            if (((HiddenField)grow.FindControl("SubID")).Value.Equals(SubID))
            {
                grow.BackColor = System.Drawing.Color.Yellow;
                return true;
            }
        }
        return false;
    }

    GridViewRow FindRow(string s, int i)
    {
        if (i == 1)
        {
            foreach (GridViewRow grow in ListOfRow)
                if (s.Equals(((HiddenField)grow.FindControl("SubID")).Value))
                    return grow;
        }
        else
        {
            foreach (GridViewRow grow in ListOfRow)
            {
                string[] dates = ((Label)grow.FindControl("Day")).Text.Replace("<br/>", ",").Split(',');
                string[] periods = ((Label)grow.FindControl("Period")).Text.Replace("<br/>", ",").Split(',');

                for (int j = 0; j < dates.Length; j++)
                {
                    if ((dates[j] + periods[j]).Equals(s))
                        return grow;
                }
            }
        }
        return null;
    }

    //  Display error color info
    bool displayErrorInfo(string error, string s, int i)
    {
        //  hightlight error row 
        FindRow(s, i).BackColor = System.Drawing.Color.Yellow;
        return displayErrorInfo(error);
    }

    bool displayErrorInfo(string error, GridViewRow row)
    {
        //  hightlight error row 
        row.BackColor = System.Drawing.Color.Yellow;
        return displayErrorInfo(error);
    }

    //  Display error text info
    bool displayErrorInfo(string s)
    {
        if (ShowInfo.Text.Contains("*** Lỗi : ")) ShowInfo.Text += s + "<br/>";
        else ShowInfo.Text = "*** Lỗi : " + s + "<br/>";
        return false;
    }

    //  Check row gridview info 
    List<string> SubIDList = new List<string>();
    List<string> DateList = new List<string>();
    List<GridViewRow> ListOfRow = new List<GridViewRow>();

    bool CheckGrow(string Date, string Period, string SubID, GridViewRow row)
    {
        if (SubIDList.Contains(SubID))    // Error on same subID
        {
            row.BackColor = System.Drawing.Color.Yellow;
            return displayErrorInfo(string.Format("Môn học không được trùng nhau : {0}", SubID), SubID, 1);

        }
        else SubIDList.Add(SubID);

        string[] dates = Date.Replace("<br/>", ",").Split(',');
        string[] periods = Period.Replace("<br/>", ",").Split(',');
        for (int i = 0; i < dates.Length; i++)
        {
            string dateandperiod = dates[i] + periods[i];
            if (DateList.Contains(dateandperiod))      // Error on samq datetime
            {
                row.BackColor = System.Drawing.Color.Yellow;
                return displayErrorInfo(string.Format("Giờ học không được trùng nhau ! Thứ {0} Ca {1}", dates[i], periods[i]), dateandperiod, 2);
            }
            else DateList.Add(dateandperiod);
        }

        ListOfRow.Add(row);
        return true;
    }

    //  Check condition about all preinfo to register item
    protected bool CheckCondition(List<GridViewRow> listSubID, ref int sum)
    {
        ShowInfo.Text = "";
        listSubID = new List<GridViewRow>();

        int inum = 0;
        using (SqlConnection scon = new SqlConnection(ConnectionString))
        {
            scon.Open();
            using (SqlCommand scom = new SqlCommand("Select SI.PreSubID,S.SubNm,SI.typ from SubInfo as SI, Subject " +
            "as S where ( SI.PreSubID = S.subID ) and ( SI.SubID = @SubID ) order by typ ", scon))
            {
                using (SqlCommand scom1 = new SqlCommand("SELECT Top 1 Mark FROM Mark " +
                "WHERE (StuId = @StuID) AND (SubId = @SubID) AND (Mark >= 50) ", scon))
                {
                    scom1.Parameters.Add("@StuID", userName);
                    scom.Parameters.Add("@SubID", "");
                    scom1.Parameters.Add("@SubID", "");
                    foreach (GridViewRow grow in GridView1.Rows)
                    {
                        //  If row is checked then break in 
                        grow.BackColor = System.Drawing.Color.Transparent;
                        if (((CheckBox)grow.FindControl("chkSelect")).Checked)
                        {
                            //  Check about same subID and date
                            string SubID = ((HiddenField)grow.FindControl("SubID")).Value;
                            string Date = ((Label)grow.FindControl("Day")).Text;
                            string Period = ((Label)grow.FindControl("Period")).Text;

                            if (!CheckGrow(Date, Period, SubID, grow)) return false;
                            else grow.BackColor = System.Drawing.Color.AliceBlue;

                            #region // Check PreSubID : not check at this verion
                            /*  Not check in this version
                            //  Check condition about preSubID
                            scom.Parameters["@SubID"].Value = SubID;
                            try
                            {
                                //scom.Prepare();
                                sReader = scom.ExecuteReader();
                                string S = ""; int type = 1;
                                while (sReader.Read())
                                {
                                    if (int.Parse(sReader.GetValue(2).ToString()) != type)
                                    {
                                        type++;
                                        if (S.Equals("")) break;
                                        else S = "";
                                    }
                                    scom1.Parameters["@SubID"].Value = sReader.GetValue(0) as string;
                                    if (getInt(scom1.ExecuteScalar()) == 0)  // Will true if drop remain data
                                        S += sReader.GetValue(1) + " ( " + sReader.GetValue(0) + " ),";
                                }
                                if (!S.Equals(""))
                                    displayErrorInfo("Bạn chưa học môn " + S.Remove(S.Length - 1) +
                                    " là môn tiên quyết của môn " + ((LinkButton)grow.FindControl("SubNm")).Text, grow);
                                sReader.Close();
                            }
                            catch(Exception ex){}
                            */
                            #endregion

                            sum += int.Parse(grow.Cells[2].Text);
                            inum++;

                        }
                    }
                }
            }
        }

        //  Check condition about Qui che : MaxReg
        //  Num of credits must larger than 0

        //  Check conditonn about  MinReg
        //  Check condition about Qui che : maxReg of TB and Yeu
        //  if( TB Student : StuID = @StuID and AMark >= 5.0 & < 6 --> Sum < SumMaxTB
        //  else Average >=4.0 & < 5.0 --> Sum < SumMaxYeu        

        if (inum == 0)
            displayErrorInfo("Tổng số môn đăng kí phải lớn hơn 0!");

        if (ShowInfo.Text.Equals(""))
            return true;
        else return false;
    }

    int GetState()
    {
        if (Session["State"] == null)
            Session.Add("State", 0);
        return (int)Session["State"];
    }

    int UpdateDatabaseSchedule(ref List<GridViewRow> listMain, bool updateState)
    {
        List<GridViewRow> list = new List<GridViewRow>();
        int sum = 0;
        using (SqlConnection scon = new SqlConnection(ConnectionString))
        {
            scon.Open();
            using (SqlCommand scom = new SqlCommand("Select ClassID from RegisterInfo where (StuID = @StuID )", scon))
            {
                scom.Parameters.Add("@StuID", userName);
                if (GetState() == 6)
                {
                    //  Delete all ClassID unchecked
                    using (SqlDataReader sreader = scom.ExecuteReader())
                    {
                        using (SqlCommand scom1 = new SqlCommand("Delete from RegisterInfo where StuID = @StuID and ClassID = @ClassID", scon))
                        {
                            scom1.Parameters.Add("@StuID", userName);
                            scom1.Parameters.Add("@ClassID", "0");
                            while (sreader.Read())
                            {
                                foreach (GridViewRow row in GridView1.Rows)
                                {
                                    if (((HiddenField)row.FindControl("ClassID")).Value.Equals(sreader.GetValue(0).ToString()))  // Exist
                                    {
                                        if (!((CheckBox)row.FindControl("chkselect")).Checked)
                                        {
                                            scom1.Parameters["@ClassID"].Value = sreader.GetValue(0).ToString();
                                            try { scom1.ExecuteNonQuery(); }
                                            catch (Exception ex) { }
                                        }
                                        break;
                                    }

                                }
                            }
                        }
                    }
                }

                scom.CommandText = "Insert into RegisterInfo(StuId,ClassID,SubID,Date,ReReg) values" +
                "(@StuID,@ClassID,@SubID,getDate(),@Value)";
                scom.Parameters.Add("@ClassID", "");
                scom.Parameters.Add("@SubID", "");
                scom.Parameters.Add("@Value", 0);

                foreach (GridViewRow grow in GridView1.Rows)
                {
                    if (((CheckBox)grow.FindControl("chkselect")).Checked)
                    {
                        grow.BackColor = System.Drawing.Color.Transparent;
                        scom.Parameters["@SubID"].Value = ((HiddenField)grow.FindControl("SubID")).Value;
                        scom.Parameters["@ClassID"].Value = ((HiddenField)grow.FindControl("ClassID")).Value;
                        if (getRereg().Contains(scom.Parameters["@SubID"].Value.ToString()))
                            scom.Parameters["@Value"].Value = grow.Cells[2].Text;
                        else scom.Parameters["@Value"].Value = 0;
                        try
                        {
                            sum += int.Parse(grow.Cells[2].Text);
                            scom.ExecuteNonQuery();
                        }
                        catch (Exception e) { ShowInfo.Text = "Có lỗi xảy ra"; }
                    }
                }

                //  Update Curnm 
                scom.CommandText = "Update ScheduleM set CurNm = (select count(*) from RegisterInfo " +
                "where ScheduleM.ClassID = RegisterInfo.ClassID)";
                try { scom.ExecuteNonQuery(); }
                catch (Exception ex) { }
            }
        }
        Session["State"] = 0;
        SetDataSourceInfo();
        SetDisplayForm();
        GridView1.DataBind();

        return sum;
    }

    List<String> getRereg()
    {
        if (Session["ReReg"] == null) Session.Add("ReReg", Reregsubject);
        return (List<String>)Session["Rereg"];
    }

    void SetReregSession()
    {
        if (Session["ReReg"] == null) Session.Add("ReReg", Reregsubject);
        else Session["Rereg"] = Reregsubject;
    }

    //  Confirm user and give some info to user
    int ConfirmtoReg()
    {
        int i = 0;
        int sum = 0;
        string Comment = "";
        using (SqlConnection scon = new SqlConnection(ConnectionString))
        {
            scon.Open();
            using (SqlCommand scom = new SqlCommand("Select count(*) from Mark where (StuID = @StuID) and (SubID = @SubID) and (Mark >= 50)", scon))
            {
                scom.Parameters.Add("@StuID", userName);
                scom.Parameters.Add("@SubId", "");
                foreach (GridViewRow grow in GridView1.Rows)
                {
                    grow.BackColor = System.Drawing.Color.Transparent;
                    if (!((CheckBox)grow.FindControl("chkSelect")).Checked) grow.Visible = false;
                    else
                    {
                        i++;
                        scom.Parameters["@SubID"].Value = ((HiddenField)grow.FindControl("SubID")).Value;
                        string SubNm = ((LinkButton)grow.FindControl("SubNm")).Text;
                        try
                        {
                            if (getInt(scom.ExecuteScalar()) > 0)
                            {
                                Comment += SubNm + " ( " + scom.Parameters["@SubID"].Value + " ) ,";
                                grow.BackColor = System.Drawing.Color.AntiqueWhite;
                                sum += int.Parse(grow.Cells[2].Text);
                                Reregsubject.Add(scom.Parameters["@SubID"].Value.ToString());
                            }
                        }
                        catch (Exception ex) { }
                    }
                }
            }
        }
        if (Comment != "") ShowInfo.Text += "**** Chú ý : Bạn đã học môn " + Comment.Remove(Comment.Length - 1) +
        ". Bạn có muốn đăng kí học lại không ?<br/>";
        else ShowInfo.Text = "*** Bạn có đồng ý đăng kí những môn học trên không ?<br/>";
        EditButton1.Text = "Đồng ý ";
        return sum;
    }

    protected void EditButton1_Click(object sender, EventArgs e)
    {
        //  Edit command
        if ((int)GetState() == 0)
        {
            Session["State"] = 5;
            CheckStateInfo();
            SetDisplayForm();
            SetDataSourceInfo();
            GridView1.DataBind();
            DropDownList1.Enabled = true;
        }
        else
        {
            int sum = 0;
            int sub = 0;
            if ((int)GetState() == 1 || (int)GetState() == 5)    //  Edit command
            {
                listSubID = new List<GridViewRow>();
                if (!CheckCondition(listSubID, ref sum)) return;
                else
                {
                    Hide("*");
                    sub = ConfirmtoReg();
                    Session["State"] = (int)GetState() + 1;   //  Change to Confirm info           
                    SetReregSession();
                    DropDownList1.Enabled = false;
                }
                DK.Text = sum.ToString();
                Sum.Text = (sum + int.Parse(Dahoc.Text) - sub - subRegifReReg).ToString();
                SumTL.Text = (sum + int.Parse(DaTL.Text) - sub - subRegifReReg).ToString();
            }
            else if ((GetState() == 2) || (GetState() == 6))
            {
                sum = UpdateDatabaseSchedule(ref listSubID, UpdateSate);
                if (ShowInfo.Text.Equals("")) ShowInfo.Text = " *** Bạn đã đăng kí thành công !<br/><br/>";
            }
        }
    }

    //  Select row to display in gridview
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList dropdownlist = (DropDownList)sender;
        Hide(dropdownlist.SelectedValue);
    }

    void Hide(string type)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (type != "*" && ((HiddenField)row.FindControl("Type")).Value != type)
                row.Visible = false;
            else { row.Visible = true; }
        }
    }

    protected void GridView1_DataBound(object sender, EventArgs e)
    {
        //  Check count of rows
        int sum = 0;
        if (GetState() == 1 || GetState() == 5)
        {
            using (SqlConnection scon = new SqlConnection(ConnectionString))
            {
                scon.Open();
                using (SqlCommand scom = new SqlCommand("Select [ClassID] from RegisterInfo where (StuID = @StuID)", scon))
                {
                    scom.Parameters.Add("@StuID", userName);
                    try
                    {
                        SqlDataReader sreader = scom.ExecuteReader();
                        while (sreader.Read())
                        {
                            foreach (GridViewRow grow in GridView1.Rows)
                            {
                                if (!((CheckBox)grow.FindControl("chkSelect")).Checked)
                                {
                                    string ClassID = ((HiddenField)grow.FindControl("ClassID")).Value;
                                    if (ClassID == sreader.GetValue(0).ToString())
                                    {
                                        grow.BackColor = System.Drawing.Color.AliceBlue;
                                        ((CheckBox)grow.FindControl("chkSelect")).Checked = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex) { }
                }
            }
        }
        else
        {
            foreach (GridViewRow grow in GridView1.Rows)
            {
                try
                {
                    if (GetState() == 0) sum += int.Parse(grow.Cells[2].Text);
                    else if (((CheckBox)grow.FindControl("chkselect")).Checked)
                    {
                        sum += int.Parse(grow.Cells[2].Text);
                    }
                }
                catch (Exception ex) { }
            }
            if (Sum.Text.Equals("0"))
            {
                DK.Text = sum.ToString();
                Sum.Text = (sum + int.Parse(Dahoc.Text) - subRegifReReg).ToString();
                SumTL.Text = (sum + int.Parse(DaTL.Text) - subRegifReReg).ToString();
            }
        }
    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        ShowInfoAboutSug.Text = "";
        using (SqlConnection scon = new SqlConnection(ConnectionString))
        {
            scon.Open();
            using (SqlCommand scom = new SqlCommand("Insert into SuggestionInfo " +
            " values(@StuID,@SubID)", scon))
            {
                scom.Parameters.Add("@StuID", userName);
                scom.Parameters.Add("@SubID", DropDownList2.SelectedValue);
                try { scom.ExecuteNonQuery(); ShowInfoAboutSug.Text = string.Format("--> Thành công : {0}", DropDownList2.SelectedValue); }
                catch (Exception ex) { ShowInfoAboutSug.Text = "--> Lỗi : Đã đề nghị môn này!"; }
            }
        }
    }

    public string getHiV()
    {
        int i = 0;
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.Visible)
                if (((HiddenField)row.FindControl("SubID")).Value.StartsWith("ENG0") ||
                    ((HiddenField)row.FindControl("ClassID")).Value.Equals("CE112.A31"))
                    i += 2;
                else i++;

            if (i > 20) return HeightofDIV;
        }
        return (i * 28 + 65).ToString() + "px";

    }

    public string GetDept(string _Dept)
    {
        switch (_Dept)
        {
            case "CS": return "Khoa học máy tính";
            case "IS": return "Hệ thống thông tin";
            case "NT": return "Mạng máy tính & truyền thông";
            case "CE": return "Kỹ thuật máy tính";
            case "SE": return "Kỹ thuật phần mềm ";
            case "TE": return "Cử nhân tài năng";
            case "AE": return "Chương trình tiên tiến HTTT";
            default: return "Chưa xác định";
        }
    }

    public string getCenter(string s)
    {
        return s.Replace(",", "<br/>");
    }

}